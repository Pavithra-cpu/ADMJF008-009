package com.model;

public class Country {

	private String name;
//	private int population;

	

	/*
	 * public Country(String name, int population) { super(); this.name = name;
	 * this.population = population; }
	 */

	public String getName() {
		return name;
	}

	public Country() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setName(String name) {
		this.name = name;
	}

	public Country(String name) {
		super();
		this.name = name;
	}

	/*
	 * public int getPopulation() { return population; }
	 * 
	 * public void setPopulation(int population) { this.population = population; }
	 */

	
}
