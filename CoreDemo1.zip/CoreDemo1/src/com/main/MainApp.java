package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.model.Country;

public class MainApp {

	public static void main(String[] args) {
		//ClassPathXmlApplicationContext cs=new ClassPathXmlApplicationContext("beans.xml");
		@SuppressWarnings("resource")
		ApplicationContext c=new AnnotationConfigApplicationContext(AppConfig.class);
		Country countryBean=(Country) c.getBean("country1");
		String name=countryBean.getName();
		//int population=countryBean.getPopulation();
		//System.out.println("Country population:"+population);
		System.out.println("Country name:"+name);
		//c.close();

	}

}
