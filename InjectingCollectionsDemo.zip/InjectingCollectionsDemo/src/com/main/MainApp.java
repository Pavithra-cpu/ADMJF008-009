package com.main;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Country;

public class MainApp {

	public static void main(String[] args) {
		
ApplicationContext appContext=new ClassPathXmlApplicationContext("bean.xml");
		
		Country countryObj=(Country) appContext.getBean("countryBean");
		
		countryObj.printListOfStates();

	}

}
