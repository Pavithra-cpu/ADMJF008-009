package com.model;

import java.util.List;

public class Country {

	private String countryName;
	List listOfStates;

	

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public List getListOfStates() {
		return listOfStates;
	}

	public void setListOfStates(List listOfStates) {
		this.listOfStates = listOfStates;
	}
	
	public void printListOfStates()
	{
		System.out.println("Some of the state in India are:");
		for(String state:listOfStates)
		{
			System.out.println(state);
		}
	}
}
