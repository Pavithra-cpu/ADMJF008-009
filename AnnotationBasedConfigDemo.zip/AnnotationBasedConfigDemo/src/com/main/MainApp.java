package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.AppConfig;
import com.model.Country;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(AppConfig.class);
		Country c=(Country) ac.getBean("countryObj");
		String countryName=c.getCountryName();
		System.out.println("Country Name "+countryName);

	}

}
