package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.model.Country;

@Configuration
public class AppConfig {

	@Bean(name="countryObj")
	public Country getCountry()
	{
		return new Country("India");
	}
	
}
