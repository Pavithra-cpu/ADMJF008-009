package com.model;

public class Capital {

	private String capitalName;

	public Capital() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Capital(String capitalName) {
		super();
		this.capitalName = capitalName;
	}

	public String getCapitalName() {
		return capitalName;
	}

	public void setCapitalName(String capitalName) {
		this.capitalName = capitalName;
	}
}
