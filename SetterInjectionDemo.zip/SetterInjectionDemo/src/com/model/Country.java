package com.model;

public class Country {

	private String countryName;
	private Capital capital;

	public Country() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Country(String countryName, Capital capital) {
		super();
		this.countryName = countryName;
		this.capital = capital;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Capital getCapital() {
		return capital;
	}

	public void setCapital(Capital capital) {
		this.capital = capital;
	}
}
