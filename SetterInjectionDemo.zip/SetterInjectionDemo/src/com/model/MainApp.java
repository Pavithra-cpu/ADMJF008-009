package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext appContext=new ClassPathXmlApplicationContext("bean.xml");
		
		Country countryObj=(Country) appContext.getBean("countryBean");
		
		String countryName=countryObj.getCountryName();
		String capitalName=countryObj.getCapital().getCapitalName();
		
		System.out.println(capitalName+"is capital of "+countryName);
		

	}

}
