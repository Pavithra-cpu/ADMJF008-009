package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext appContext=new ClassPathXmlApplicationContext("bean.xml");
		
		Country countryObj1=(Country) appContext.getBean("country");
		countryObj1.setCountryName("India");
		System.out.println("CountryName :"+countryObj1.getCountryName());
		
		Country countryObj2=(Country) appContext.getBean("country");
		System.out.println("CountryName :"+countryObj2.getCountryName());
		

	}

}
