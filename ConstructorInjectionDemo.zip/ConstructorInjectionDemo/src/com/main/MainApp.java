package com.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Country;

public class MainApp {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");
		Country countryBean = (Country) ac.getBean("country");
		
		String name = countryBean.getName();
		System.out.println("Country name: " + name);

		int population = countryBean.getPopulation();
		System.out.println("Country population: " + population);

		ac.close();

	}

}
